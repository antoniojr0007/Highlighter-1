/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
//import sun.util.logging.PlatformLogger;

/**
 *
 * @author internet
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class MyConnection {
        public Statement stm; // responsavel por preparar e realizar pesquisas no banco de dados
        public ResultSet rs; // responsavel por armazenar o resultado de uma pesquisa passada para o static
        private String driver = "org.mysql.jdbc.Driver"; // responsavél por identificar o serviço de banco de dados
        private String caminho = "jdbc:mysql://localhost:3306/cadastro"; // responsavél por setar o local do banco de dados
        private String usuario = "root"; // usuario do banco de dados
        private String senha = ""; // senha
        public Connection conn; // Responsavel por realizar a conexão com o banco de dados
        
        public void  conexao () { // Metodo responsavel por realizar a conexão com o mySQL
            try { // Bloco lógico Boleano
                System.setProperty ("jdbc.Drivers", driver); // seta a propriedade do Driver de conexão
                conn = DriverManager.getConnection (caminho, usuario, senha); // realiza a conexão com o mySQL
                //JOptionPane.showMessageDialog (null, "MySQL conectado com sucesso!"); // Valida a conexão (True)
            } catch (SQLException ex) {
                Logger.getLogger(MyConnection.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, "Erro de conexão!"); // False
            }
        }
        
        public void desconecta(){ // Fechar a conexão mySQL
            try {
                conn.close();
                JOptionPane.showMessageDialog (null, "Desconectado com sucesso");
            } catch (SQLException ex) {
                Logger.getLogger(MyConnection.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog (null, "Erro ao fechar a conexão");
            }
        }

        public void executaSQL(String sql) throws SQLException{
        stm = (Statement) conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
        rs = stm.executeQuery(sql);
        }
        
        
        public void executaInsert(String sql) throws SQLException{
        stm = (Statement) conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
        stm.executeUpdate(sql);
        }
}
        
   




